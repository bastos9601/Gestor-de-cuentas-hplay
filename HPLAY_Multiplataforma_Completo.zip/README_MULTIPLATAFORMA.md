# 🎬 HPLAY - Gestor de Cuentas Streaming Multiplataforma

## 🌟 **Descripción General**

HPLAY es un sistema profesional para gestionar cuentas de streaming de forma segura, disponible en múltiples plataformas para máxima compatibilidad con todos tus dispositivos.

---

## 🚀 **Versiones Disponibles**

### **1. 🖥️ Aplicación de Escritorio (Windows)**
- **Archivo**: `GestorCuentasHPLAY.exe`
- **Plataforma**: Windows 10/11 (64-bit)
- **Características**: 
  - Interfaz nativa de Windows
  - Sin necesidad de navegador
  - Funciona offline
  - Sistema de encriptación local

### **2. 🌐 Aplicación Web (Multiplataforma)**
- **Archivo**: `web_app/app.py`
- **Plataformas**: Windows, macOS, Linux, Android, iOS, Tablets
- **Características**:
  - Interfaz web responsiva
  - Acceso desde cualquier dispositivo
  - Base de datos SQLite
  - Diseño adaptativo para móviles

---

## 📱 **Compatibilidad por Dispositivo**

| Dispositivo | Escritorio | Web | Notas |
|-------------|------------|-----|-------|
| **Windows PC** | ✅ Nativo | ✅ Navegador | Ambas versiones |
| **Mac** | ❌ No disponible | ✅ Navegador | Solo versión web |
| **Linux** | ❌ No disponible | ✅ Navegador | Solo versión web |
| **Android** | ❌ No disponible | ✅ Navegador | Versión web móvil |
| **iOS** | ❌ No disponible | ✅ Navegador | Versión web móvil |
| **Tablets** | ❌ No disponible | ✅ Navegador | Versión web adaptativa |
| **Smart TVs** | ❌ No disponible | ✅ Navegador | Versión web básica |

---

## 🛠️ **Instalación por Plataforma**

### **🖥️ Windows (Aplicación de Escritorio)**

1. **Descarga**: Obtén la carpeta `HPLAY_Distribucion`
2. **Instalación**: Ejecuta `INSTALAR.bat`
3. **Uso**: Haz doble clic en `GestorCuentasHPLAY.exe`

### **🌐 Multiplataforma (Aplicación Web)**

1. **Requisitos**: Python 3.8+
2. **Instalación**: Ejecuta `instalar_web.bat` (Windows) o `pip install -r requirements.txt`
3. **Uso**: Ejecuta `python app.py` y abre http://localhost:5000

---

## 🔐 **Acceso al Sistema**

### **Credenciales por Defecto**
- **Usuario**: `admin`
- **Contraseña**: `admin123`

### **Cambio de Credenciales**
- **Escritorio**: Botón "🔐 Cambiar Clave" en la interfaz
- **Web**: Menú "Cambiar Clave" en la barra de navegación

---

## 💡 **Funciones Principales**

✅ **Gestión de Cuentas**
- Agregar, editar, eliminar cuentas
- Búsqueda y filtrado avanzado
- Categorización por servicio

✅ **Sistema de Seguridad**
- Login con autenticación
- Encriptación de datos sensibles
- Control de acceso por usuario

✅ **Gestión de Clientes**
- Información completa del cliente
- Historial de transacciones
- Métodos de pago

✅ **Notificaciones**
- Recordatorios de vencimiento
- Alertas automáticas
- Integración con WhatsApp

✅ **Estadísticas**
- Dashboard en tiempo real
- Métricas de negocio
- Reportes visuales

---

## 📱 **Características Móviles (Versión Web)**

### **Responsive Design**
- Adaptación automática a pantallas pequeñas
- Navegación táctil optimizada
- Botones de tamaño apropiado para móviles

### **Funcionalidades Móviles**
- Menú hamburguesa colapsable
- Tablas con scroll horizontal
- Botones flotantes de acción
- Gestos táctiles compatibles

### **Optimizaciones**
- Carga rápida en conexiones lentas
- Interfaz minimalista para pantallas pequeñas
- Navegación por gestos intuitiva

---

## 🔧 **Configuración Avanzada**

### **Acceso Remoto (Versión Web)**

1. **Encuentra tu IP local**:
   ```bash
   # Windows
   ipconfig
   
   # Mac/Linux
   ifconfig
   ```

2. **Accede desde otros dispositivos**:
   ```
   http://[TU_IP]:5000
   ```

3. **Configuración de firewall**:
   - Permite conexiones al puerto 5000
   - Configura reglas para tu red local

### **Base de Datos**
- **Escritorio**: Archivos encriptados localmente
- **Web**: Base de datos SQLite con encriptación

---

## 📊 **Comparación de Versiones**

| Característica | Escritorio | Web |
|----------------|------------|-----|
| **Velocidad** | ⚡ Muy rápida | 🚀 Rápida |
| **Offline** | ✅ Completo | ❌ Requiere servidor |
| **Multiplataforma** | ❌ Solo Windows | ✅ Universal |
| **Móvil** | ❌ No disponible | ✅ Optimizado |
| **Mantenimiento** | 🔧 Manual | 🔄 Automático |
| **Escalabilidad** | 📈 Limitada | 📈 Ilimitada |

---

## 🚨 **Solución de Problemas**

### **Aplicación de Escritorio**
- **No inicia**: Verifica que todos los archivos estén presentes
- **Error de antivirus**: Agrega excepción para la carpeta
- **Permisos**: Ejecuta como administrador

### **Aplicación Web**
- **Puerto ocupado**: Cambia el puerto en `app.py`
- **Dependencias**: Ejecuta `pip install -r requirements.txt`
- **Acceso remoto**: Verifica configuración de firewall

### **Dispositivos Móviles**
- **Lentitud**: Verifica conexión WiFi
- **Interfaz**: Usa navegador actualizado
- **Compatibilidad**: Chrome/Safari recomendados

---

## 🔄 **Actualizaciones**

### **Escritorio**
1. Descarga nueva versión
2. Reemplaza solo el archivo `.exe`
3. Mantén archivos de datos

### **Web**
1. Actualiza código fuente
2. Reinicia la aplicación
3. Base de datos se mantiene

---

## 📞 **Soporte Técnico**

### **Canales de Soporte**
- **Email**: soporte@hplay.com
- **WhatsApp**: +51 XXX XXX XXX
- **Documentación**: README completo

### **Información del Sistema**
- **Versión**: 1.0.0
- **Última actualización**: Agosto 2025
- **Compatibilidad**: Windows 10+, Python 3.8+

---

## 🎯 **Recomendaciones de Uso**

### **Para Uso Personal**
- **Recomendado**: Aplicación de escritorio
- **Ventaja**: Rápida, offline, segura

### **Para Uso Empresarial**
- **Recomendado**: Aplicación web
- **Ventaja**: Acceso desde cualquier lugar, colaboración

### **Para Dispositivos Móviles**
- **Recomendado**: Aplicación web
- **Ventaja**: Optimizada para móviles, responsive

---

## 📄 **Licencia y Términos**

© 2025 HPLAY - Todos los derechos reservados

**Términos de Uso**:
- Uso personal y comercial permitido
- No redistribuir sin autorización
- Soporte técnico incluido

---

## 🚀 **Próximas Funcionalidades**

- [ ] **App Móvil Nativa** (Android/iOS)
- [ ] **Sincronización en la Nube**
- [ ] **API REST para integraciones**
- [ ] **Reportes PDF/Excel**
- [ ] **Backup automático**
- [ ] **Multi-usuario con roles**

---

*¿Necesitas ayuda? Consulta la documentación o contacta a nuestro equipo de soporte.*
