from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import json
import os
from datetime import datetime, timedelta
import threading
import time

app = Flask(__name__)
app.secret_key = 'hplay_secret_key_2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hplay_gestor.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Modelo de base de datos
class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    es_admin = db.Column(db.Boolean, default=False)

class Cuenta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    servicio = db.Column(db.String(100), nullable=False)
    cliente = db.Column(db.String(100), nullable=False)
    num_cliente = db.Column(db.String(50))
    metodo = db.Column(db.String(50))
    precio = db.Column(db.String(50))
    telefono = db.Column(db.String(20))
    fecha_inicio = db.Column(db.String(20))
    fecha_fin = db.Column(db.String(20))
    usuario = db.Column(db.String(100), nullable=False)
    password = db.Column(db.String(100), nullable=False)
    vencida = db.Column(db.Boolean, default=False)
    fecha_creacion = db.Column(db.DateTime, default=datetime.utcnow)

class Notificacion(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    servicio = db.Column(db.String(100), nullable=False)
    cliente = db.Column(db.String(100), nullable=False)
    tipo = db.Column(db.String(50), nullable=False)
    estado = db.Column(db.String(50), nullable=False)
    fecha = db.Column(db.DateTime, default=datetime.utcnow)

# Crear tablas
with app.app_context():
    db.create_all()
    
    # Crear usuario admin por defecto si no existe
    if not Usuario.query.filter_by(username='admin').first():
        admin = Usuario(
            username='admin',
            password_hash=generate_password_hash('admin123'),
            es_admin=True
        )
        db.session.add(admin)
        db.session.commit()

# Rutas de la aplicación
@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = Usuario.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            session['username'] = user.username
            session['es_admin'] = user.es_admin
            flash('¡Bienvenido!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Usuario o contraseña incorrectos', 'error')
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Sesión cerrada', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cuentas = Cuenta.query.all()
    total_cuentas = len(cuentas)
    
    # Estadísticas
    metodos = {}
    clientes = {}
    precio_total = 0
    
    for cuenta in cuentas:
        # Contar métodos
        metodo = cuenta.metodo or 'Sin método'
        metodos[metodo] = metodos.get(metodo, 0) + 1
        
        # Contar clientes
        cliente = cuenta.cliente or 'Sin cliente'
        clientes[cliente] = clientes.get(cliente, 0) + 1
        
        # Calcular precio total
        try:
            precio_str = cuenta.precio or '0'
            precio_limpio = ''.join(c for c in precio_str if c.isdigit() or c == '.')
            if precio_limpio:
                precio_total += float(precio_limpio)
        except:
            continue
    
    stats = {
        'total_cuentas': total_cuentas,
        'clientes_unicos': len(clientes),
        'metodos': len(metodos),
        'precio_total': f"S/. {precio_total:.2f}"
    }
    
    return render_template('dashboard.html', cuentas=cuentas, stats=stats)

@app.route('/agregar_cuenta', methods=['GET', 'POST'])
def agregar_cuenta():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        nueva_cuenta = Cuenta(
            servicio=request.form['servicio'],
            cliente=request.form['cliente'],
            num_cliente=request.form['num_cliente'],
            metodo=request.form['metodo'],
            precio=request.form['precio'],
            telefono=request.form['telefono'],
            fecha_inicio=request.form['fecha_inicio'],
            fecha_fin=request.form['fecha_fin'],
            usuario=request.form['usuario'],
            password=request.form['password']
        )
        
        db.session.add(nueva_cuenta)
        db.session.commit()
        
        flash('Cuenta agregada exitosamente', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('agregar_cuenta.html')

@app.route('/editar_cuenta/<int:id>', methods=['GET', 'POST'])
def editar_cuenta(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cuenta = Cuenta.query.get_or_404(id)
    
    if request.method == 'POST':
        cuenta.servicio = request.form['servicio']
        cuenta.cliente = request.form['cliente']
        cuenta.num_cliente = request.form['num_cliente']
        cuenta.metodo = request.form['metodo']
        cuenta.precio = request.form['precio']
        cuenta.telefono = request.form['telefono']
        cuenta.fecha_inicio = request.form['fecha_inicio']
        cuenta.fecha_fin = request.form['fecha_fin']
        cuenta.usuario = request.form['usuario']
        cuenta.password = request.form['password']
        
        db.session.commit()
        flash('Cuenta actualizada exitosamente', 'success')
        return redirect(url_for('dashboard'))
    
    return render_template('editar_cuenta.html', cuenta=cuenta)

@app.route('/eliminar_cuenta/<int:id>')
def eliminar_cuenta(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    cuenta = Cuenta.query.get_or_404(id)
    db.session.delete(cuenta)
    db.session.commit()
    
    flash('Cuenta eliminada exitosamente', 'success')
    return redirect(url_for('dashboard'))

@app.route('/buscar_cuentas')
def buscar_cuentas():
    if 'user_id' not in session:
        return jsonify({'error': 'No autorizado'})
    
    termino = request.args.get('q', '').lower()
    
    if not termino:
        cuentas = Cuenta.query.all()
    else:
        cuentas = Cuenta.query.filter(
            db.or_(
                Cuenta.servicio.ilike(f'%{termino}%'),
                Cuenta.cliente.ilike(f'%{termino}%'),
                Cuenta.num_cliente.ilike(f'%{termino}%'),
                Cuenta.metodo.ilike(f'%{termino}%'),
                Cuenta.usuario.ilike(f'%{termino}%')
            )
        ).all()
    
    resultado = []
    for cuenta in cuentas:
        resultado.append({
            'id': cuenta.id,
            'servicio': cuenta.servicio,
            'cliente': cuenta.cliente,
            'num_cliente': cuenta.num_cliente,
            'metodo': cuenta.metodo,
            'precio': cuenta.precio,
            'telefono': cuenta.telefono,
            'fecha_inicio': cuenta.fecha_inicio,
            'fecha_fin': cuenta.fecha_fin,
            'usuario': cuenta.usuario,
            'password': cuenta.password,
            'vencida': cuenta.vencida
        })
    
    return jsonify(resultado)

@app.route('/cambiar_clave', methods=['GET', 'POST'])
def cambiar_clave():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        clave_actual = request.form['clave_actual']
        nueva_clave = request.form['nueva_clave']
        confirmar_clave = request.form['confirmar_clave']
        
        user = Usuario.query.get(session['user_id'])
        
        if not check_password_hash(user.password_hash, clave_actual):
            flash('Clave actual incorrecta', 'error')
        elif nueva_clave != confirmar_clave:
            flash('Las claves no coinciden', 'error')
        else:
            user.password_hash = generate_password_hash(nueva_clave)
            db.session.commit()
            flash('Clave cambiada exitosamente', 'success')
            return redirect(url_for('dashboard'))
    
    return render_template('cambiar_clave.html')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
